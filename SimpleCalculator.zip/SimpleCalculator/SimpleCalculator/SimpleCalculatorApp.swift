//
//  SimpleCalculatorApp.swift
//  SimpleCalculator
//
//  Created by Chiune Honda - 895 on 2025-02-18.
//

import SwiftUI

@main
struct SimpleCalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
